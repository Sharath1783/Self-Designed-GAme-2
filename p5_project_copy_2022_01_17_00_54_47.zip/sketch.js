var duck, duckIMG
var platform, platformIMG
var coins, coinsIMG
var nightIMG, night
var score = 0
var gameState = "start"
var text1 = "Press Space To Restart the Game"


function preload()
{
 nightIMG = loadImage("nigh background.jpg");
  duckIMG = loadImage("bird2img.png");
  platformIMG = loadImage("platformimg.png");
  coinsIMG = loadImage("coinimg.png");
  
}



function setup()
{
  createCanvas(600, 600); 
  
  
  night = createSprite(200,200)
  night.addImage ("night", nightIMG);
  night.velocityY = 3;
  
  duck = createSprite(300, 550);
  duck.addImage ("duck", duckIMG);
  duck.scale = 0.13;
  
  text1.visible=false;
  
  
}

function draw()
{
  background(0);

  
  if(night.y > 400 ){
    night.y = height/4;
    
    
  }
  duck.x = World.mouseX;
  spawnDiamond();
  spawnCoins();
  drawSprites();
}


function spawnDiamond(){
  if(frameCount%175===0){
    var platform=createSprite(Math.round(random(50,500)),0,20,20)
    platform.addImage("diamond",platformIMG)
    platform.scale=0.9;
    platform.velocityY=2
    platform.lifetime=300
  }
} 
  function spawnCoins(){
  if(frameCount%80===0){
    var coins=createSprite(Math.round(random(50,500)),0,20,20)
    coins.addImage("diamond",coinsIMG)
    coins.scale=0.2;
    coins.velocityY=2
    coins.lifetime=300
  }
}